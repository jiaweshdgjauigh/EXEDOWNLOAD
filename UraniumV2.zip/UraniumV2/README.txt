
██╗░░░██╗██████╗░░█████╗░███╗░░██╗██╗██╗░░░██╗███╗░░░███╗
██║░░░██║██╔══██╗██╔══██╗████╗░██║██║██║░░░██║████╗░████║
██║░░░██║██████╔╝███████║██╔██╗██║██║██║░░░██║██╔████╔██║
██║░░░██║██╔══██╗██╔══██║██║╚████║██║██║░░░██║██║╚██╔╝██║
╚██████╔╝██║░░██║██║░░██║██║░╚███║██║╚██████╔╝██║░╚═╝░██║
░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝╚═╝░╚═════╝░╚═╝░░░░░╚═╝


▀█▀ ░█▄─░█ ░█▀▀▀ ░█▀▀▀█ ░█▀▀█ ░█▀▄▀█ ─█▀▀█ ▀▀█▀▀ ▀█▀ ░█▀▀▀█ ░█▄─░█ 　 ─█▀▀█ ░█▄─░█ ░█▀▀▄ 
░█─ ░█░█░█ ░█▀▀▀ ░█──░█ ░█▄▄▀ ░█░█░█ ░█▄▄█ ─░█── ░█─ ░█──░█ ░█░█░█ 　 ░█▄▄█ ░█░█░█ ░█─░█ 
▄█▄ ░█──▀█ ░█─── ░█▄▄▄█ ░█─░█ ░█──░█ ░█─░█ ─░█── ▄█▄ ░█▄▄▄█ ░█──▀█ 　 ░█─░█ ░█──▀█ ░█▄▄▀ 

▀█▀ ░█▄─░█ ░█▀▀▀█ ▀▀█▀▀ ░█▀▀█ ░█─░█ ░█▀▀█ ▀▀█▀▀ ▀█▀ ░█▀▀▀█ ░█▄─░█ ░█▀▀▀█ 
░█─ ░█░█░█ ─▀▀▀▄▄ ─░█── ░█▄▄▀ ░█─░█ ░█─── ─░█── ░█─ ░█──░█ ░█░█░█ ─▀▀▀▄▄ 
▄█▄ ░█──▀█ ░█▄▄▄█ ─░█── ░█─░█ ─▀▄▄▀ ░█▄▄█ ─░█── ▄█▄ ░█▄▄▄█ ░█──▀█ ░█▄▄▄█


Important Information Before Using This Executor:

Accountability:
I am NOT responsible for any bans or consequences that occur as a result of using this executor. You are using it at your own risk, and I cannot be held liable for any actions taken against your account.

Potential Bugs & Instability:
This executor may experience bugs or issues while running. It's not guaranteed to work perfectly in all circumstances, so be prepared for some possible instability. If something goes wrong, try restarting the executor or troubleshooting.

Ban Risk:
While the executor itself doesn’t guarantee a ban, the risk of detection by Roblox's anti-cheat system is always present. Roblox’s anti-cheat is far from flawless and may not always catch exploit attempts, but it can still potentially flag your account. (I strongly recommend NOT using this on your main account.)

Legal Warning:
Using exploits may violate Roblox’s Terms of Service and can lead to account suspension or bans. Always be cautious and aware of the risks before proceeding.

Instructions for Use:

Injecting the Executor:

To use the executor, you must inject it into Roblox once when you're in a game. Make sure the injection is successful before attempting to run any scripts. This is a one-time step when entering the game.
Executing Scripts:

Scripts can only be executed after the executor has been properly injected into Roblox. If the executor is not injected correctly, no scripts will run. Ensure the injection process is completed before moving forward.
Re-injecting After Roblox Closes:

If Roblox closes or crashes, you will need to re-inject the executor to regain access to the script execution functionality. This is a normal part of using third-party executors.
Executor Not Re-injecting?

If the executor fails to re-inject after Roblox closes, try closing the executor and reopening it. In some cases, restarting both the executor and Roblox might be necessary for everything to work properly.
Executor Compatibility:

This executor may not be compatible with all versions of Roblox. If you encounter issues, ensure that you're using the latest version of the executor and that your Roblox client is up to date.

NOTE:
Exploiting may ruin your consequences